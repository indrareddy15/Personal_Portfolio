import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text } from '@react-three/drei';
import { Vector3 } from 'three';
import type { WorkExperience } from '../../types/portfolio';

interface CodePanelProps {
  experience: WorkExperience;
  index: number;
  isSelected: boolean;
  onClick: () => void;
}

export const CodePanel = ({ experience, index, isSelected, onClick }: CodePanelProps) => {
  const meshRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);
  
  useFrame((state) => {
    if (!meshRef.current) return;
    
    // Floating animation
    meshRef.current.position.y = Math.sin(state.clock.elapsedTime + index) * 0.1;
    
    // Hover scale animation
    const scale = hovered || isSelected ? 1.1 : 1;
    meshRef.current.scale.lerp(new Vector3(scale, scale, scale), 0.1);
  });

  const techStack = experience.responsibilities
    .join(' ')
    .match(/\b(React|TypeScript|JavaScript|Node|AWS|SQL|MongoDB)\b/g) || [];

  return (
    <group
      ref={meshRef}
      position={[index * 4 - 4, 0, 0]}
      onClick={onClick}
      onPointerOver={() => setHovered(true)}
      onPointerOut={() => setHovered(false)}
    >
      {/* Background panel */}
      <mesh position={[0, 0, -0.1]}>
        <planeGeometry args={[3, 4]} />
        <meshStandardMaterial
          color="#1e293b"
          transparent
          opacity={0.8}
          metalness={0.5}
          roughness={0.2}
        />
      </mesh>

      {/* Code content */}
      <group position={[-1.3, 1.5, 0]}>
        {/* Company comment */}
        <Text
          position={[0, 0, 0]}
          fontSize={0.15}
          color="#94a3b8"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          // {experience.company}
        </Text>

        {/* Position function */}
        <Text
          position={[0, -0.4, 0]}
          fontSize={0.15}
          color="#2563eb"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          function {experience.position.replace(/[^a-zA-Z]/g, '')}() {'{'}
        </Text>

        {/* Duration */}
        <Text
          position={[0.2, -0.8, 0]}
          fontSize={0.15}
          color="#8b5cf6"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          const duration = "{experience.duration}";
        </Text>

        {/* Location */}
        <Text
          position={[0.2, -1.2, 0]}
          fontSize={0.15}
          color="#8b5cf6"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          const location = "{experience.location}";
        </Text>

        {/* Tech imports */}
        <Text
          position={[0, -1.8, 0]}
          fontSize={0.15}
          color="#2563eb"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          import {'{'} {techStack.join(', ')} {'}'} from "tech";
        </Text>

        {/* Closing brace */}
        <Text
          position={[0, -2.2, 0]}
          fontSize={0.15}
          color="#2563eb"
          anchorX="left"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          {'}'}
        </Text>
      </group>

      {/* Expand prompt */}
      {(hovered || isSelected) && (
        <Text
          position={[0, -1.8, 0]}
          fontSize={0.12}
          color="#94a3b8"
          anchorX="center"
          font="/fonts/JetBrainsMono-Regular.woff"
        >
          Click to expand
        </Text>
      )}
    </group>
  );
};