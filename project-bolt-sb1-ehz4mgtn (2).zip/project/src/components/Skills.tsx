import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Code2, Database, Globe, Layout, Server, Settings, Star, StarHalf } from 'lucide-react';
import { portfolioData } from '../data/portfolio';
import { useState } from 'react';
import type { Skill } from '../types/portfolio';

const skillIcons: Record<string, any> = {
  frontend: Layout,
  backend: Server,
  database: Database,
  tools: Settings,
  web: Globe,
  languages: Code2,
};

const StarRating = ({ rating }: { rating: number }) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - Math.ceil(rating);

  return (
    <div className="flex gap-1">
      {[...Array(fullStars)].map((_, i) => (
        <Star key={`full-${i}`} className="w-4 h-4 fill-primary text-primary" />
      ))}
      {hasHalfStar && <StarHalf className="w-4 h-4 fill-primary text-primary" />}
      {[...Array(emptyStars)].map((_, i) => (
        <Star key={`empty-${i}`} className="w-4 h-4 text-gray-400" />
      ))}
    </div>
  );
};

const SkillModal = ({ skills, isVisible, position }: { 
  skills: Skill[];
  isVisible: boolean;
  position: { x: number; y: number };
}) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          style={{
            position: 'fixed',
            left: `${position.x}px`,
            top: `${position.y}px`,
          }}
          className="bg-background/95 backdrop-blur-lg border border-primary/20 rounded-lg p-4 shadow-xl z-50 min-w-[300px] max-w-[400px]"
        >
          <div className="space-y-4">
            {skills.map((skill) => (
              <div key={skill.name} className="space-y-1">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">{skill.name}</h4>
                  <StarRating rating={skill.proficiency} />
                </div>
                {skill.description && (
                  <p className="text-sm text-text-secondary">{skill.description}</p>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const Skills = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });

  const handleMouseEnter = (category: string, event: React.MouseEvent) => {
    const rect = event.currentTarget.getBoundingClientRect();
    setModalPosition({
      x: rect.right + 20,
      y: rect.top,
    });
    setHoveredCategory(category);
  };

  const handleMouseLeave = () => {
    setHoveredCategory(null);
  };

  return (
    <section id="skills" className="section py-20 bg-background/50">
      <div className="container">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
        >
          Skills & Technologies
        </motion.h2>
        <div
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {portfolioData.skills.map((category, index) => {
            const Icon = skillIcons[category.name];
            return (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: index * 0.1 }}
                className="card group cursor-pointer relative"
                onMouseEnter={(e) => handleMouseEnter(category.name, e)}
                onMouseLeave={handleMouseLeave}
              >
                <div className="flex items-center gap-3 mb-4">
                  <Icon className="w-6 h-6 text-primary group-hover:text-accent transition-colors" />
                  <h3 className="text-xl font-semibold capitalize">{category.name}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <span
                      key={skill.name}
                      className="px-3 py-1 bg-primary/10 rounded-full text-sm font-medium text-primary hover:bg-primary/20 transition-colors"
                    >
                      {skill.name}
                    </span>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
      <SkillModal
        skills={portfolioData.skills.find(c => c.name === hoveredCategory)?.skills || []}
        isVisible={hoveredCategory !== null}
        position={modalPosition}
      />
    </section>
  );
};