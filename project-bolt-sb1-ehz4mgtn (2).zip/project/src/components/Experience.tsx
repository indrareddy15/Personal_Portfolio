import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { Briefcase, Calendar, MapPin, Award, Lightbulb, Cpu } from 'lucide-react';
import { portfolioData } from '../data/portfolio';
import { useState } from 'react';
import { CodePanel } from './3d/CodePanel';

export const Experience = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [selectedExperience, setSelectedExperience] = useState(0);
  const experience = portfolioData.work_experience[selectedExperience];

  return (
    <section id="experience" className="section py-20">
      <div className="container">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
        >
          Work Experience
        </motion.h2>
        <div className="grid grid-cols-1 gap-12">
          {/* 3D Code Panels */}
          <div className="h-[600px] bg-background/50 rounded-lg">
            <Canvas camera={{ position: [0, 0, 8], fov: 75 }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <group position={[0, 0, 0]}>
                {portfolioData.work_experience.map((exp, index) => (
                  <CodePanel
                    key={exp.company}
                    experience={exp}
                    index={index}
                    isSelected={index === selectedExperience}
                    onClick={() => setSelectedExperience(index)}
                  />
                ))}
              </group>
              <OrbitControls
                enableZoom={false}
                enablePan={false}
                minPolarAngle={Math.PI / 2.5}
                maxPolarAngle={Math.PI / 1.5}
              />
            </Canvas>
          </div>

          {/* Experience Details */}
          <div ref={ref} className="space-y-8">
            <motion.div
              key={experience.company}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="card"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <div>
                  <h3 className="text-2xl font-semibold flex items-center gap-2 mb-2">
                    <Briefcase className="w-6 h-6 text-primary" />
                    {experience.position}
                  </h3>
                  <p className="text-lg text-text-secondary">{experience.company}</p>
                </div>
                <div className="flex flex-col md:items-end mt-4 md:mt-0">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span className="text-text-secondary">{experience.duration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-primary" />
                    <span className="text-text-secondary">{experience.location}</span>
                  </div>
                </div>
              </div>

              <div className="grid gap-6">
                <div>
                  <h4 className="text-lg font-semibold flex items-center gap-2 mb-3">
                    <Lightbulb className="w-5 h-5 text-primary" />
                    Key Responsibilities
                  </h4>
                  <ul className="list-disc list-inside space-y-2">
                    {experience.responsibilities.map((responsibility, idx) => (
                      <li key={idx} className="text-text-secondary">{responsibility}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-semibold flex items-center gap-2 mb-3">
                    <Cpu className="w-5 h-5 text-primary" />
                    Tech Stack
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {portfolioData.skills.flatMap(category => 
                      category.skills.map(skill => (
                        <span
                          key={skill.name}
                          className="px-3 py-1 bg-primary/10 rounded-full text-sm font-medium text-primary"
                        >
                          {skill.name}
                        </span>
                      ))
                    )}
                  </div>
                </div>

                {portfolioData.awards.length > 0 && (
                  <div>
                    <h4 className="text-lg font-semibold flex items-center gap-2 mb-3">
                      <Award className="w-5 h-5 text-primary" />
                      Achievements
                    </h4>
                    <ul className="list-disc list-inside space-y-2">
                      {portfolioData.awards.map((award, idx) => (
                        <li key={idx} className="text-text-secondary">{award}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};