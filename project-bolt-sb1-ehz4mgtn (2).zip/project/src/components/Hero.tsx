import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { Download } from 'lucide-react';
import { Laptop } from './3d/Laptop';
import { portfolioData } from '../data/portfolio';

export const Hero = () => {
  const handleDownloadResume = () => {
    // Create a simple PDF with basic styling using the portfolio data
    const { name, contact, education, work_experience, skills } = portfolioData;
    
    const content = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            h1 { color: #2563eb; }
            .section { margin: 20px 0; }
            .title { color: #1e40af; margin-bottom: 10px; }
          </style>
        </head>
        <body>
          <h1>${name}</h1>
          <div class="section">
            <p>${contact.email} | ${contact.phone}</p>
            <p>LinkedIn: ${contact.linkedin} | GitHub: ${contact.github}</p>
          </div>
          <div class="section">
            <h2 class="title">Education</h2>
            <p>${education.degree} in ${education.major}</p>
            <p>${education.institution}</p>
            <p>${education.duration}</p>
          </div>
          <div class="section">
            <h2 class="title">Work Experience</h2>
            ${work_experience.map(job => `
              <div style="margin-bottom: 15px;">
                <h3>${job.position}</h3>
                <p>${job.company} | ${job.location}</p>
                <p>${job.duration}</p>
                <ul>
                  ${job.responsibilities.map(resp => `<li>${resp}</li>`).join('')}
                </ul>
              </div>
            `).join('')}
          </div>
          <div class="section">
            <h2 class="title">Skills</h2>
            ${skills.map(category => `
              <div style="margin-bottom: 10px;">
                <h3>${category.name}</h3>
                <p>${category.skills.map(skill => skill.name).join(', ')}</p>
              </div>
            `).join('')}
          </div>
        </body>
      </html>
    `;

    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${name.replace(/\s+/g, '_')}_Resume.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section className="min-h-screen flex items-center">
      <div className="container grid grid-cols-1 lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col justify-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Hi, I'm <span className="text-gradient">{portfolioData.name}</span>
          </h1>
          <p className="text-lg text-text-secondary mb-8">
            Software Engineer specializing in building exceptional digital experiences
          </p>
          <div className="flex flex-wrap gap-4">
            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-primary rounded-full text-white font-medium"
            >
              View Projects
            </motion.a>
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 border border-primary rounded-full text-primary font-medium"
            >
              Contact Me
            </motion.a>
            <motion.button
              onClick={handleDownloadResume}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-primary/10 rounded-full text-primary font-medium flex items-center gap-2 hover:bg-primary/20 transition-colors"
            >
              <Download className="w-4 h-4" />
              Download Resume
            </motion.button>
          </div>
        </motion.div>
        <div className="h-[400px] lg:h-[600px]">
          <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} />
            <Laptop />
            <OrbitControls enableZoom={false} />
          </Canvas>
        </div>
      </div>
    </section>
  );
};