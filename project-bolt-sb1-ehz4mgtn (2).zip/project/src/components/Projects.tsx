import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ExternalLink, Github, X } from 'lucide-react';
import { portfolioData } from '../data/portfolio';
import { useState } from 'react';
import type { Project } from '../types/portfolio';

const ProjectDrawer = ({ project, isOpen, onClose }: {
  project: Project | null;
  isOpen: boolean;
  onClose: () => void;
}) => {
  return (
    <AnimatePresence>
      {isOpen && project && (
        <motion.div
          initial={{ x: '100%', y: '-100%' }}
          animate={{ x: 0, y: 0 }}
          exit={{ x: '100%', y: '-100%' }}
          transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          className="fixed top-0 right-0 w-full h-screen bg-background/95 backdrop-blur-lg border-l border-primary/20 shadow-2xl z-50"
          style={{
            borderBottomLeftRadius: '100%',
            transformOrigin: 'top right',
          }}
        >
          <div className="container mx-auto h-full overflow-y-auto px-8 py-12">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 hover:bg-primary/10 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <h3 className="text-4xl font-bold text-gradient">{project.name}</h3>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <h4 className="text-xl font-semibold mb-3">Description</h4>
                    <ul className="list-disc list-inside space-y-3 text-text-secondary">
                      {project.description.map((desc, index) => (
                        <li key={index}>{desc}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="text-xl font-semibold mb-3">Timeline</h4>
                    <p className="text-text-secondary">{project.duration}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-xl font-semibold mb-3">Technologies</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {project.tech_stack.map((tech) => (
                      <span
                        key={tech}
                        className="px-4 py-2 bg-primary/10 rounded-lg text-sm font-medium text-primary text-center hover:bg-primary/20 transition-colors"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const Projects = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  return (
    <section id="projects" className="section py-20">
      <div className="container">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
        >
          Featured Projects
        </motion.h2>
        <div
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {portfolioData.projects.map((project, index) => (
            <motion.div
              key={project.name}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1 }}
              className="card group hover:border-primary/50"
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">
                  {project.name}
                </h3>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 hover:text-primary transition-colors"
                  >
                    <Github className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 hover:text-primary transition-colors"
                    onClick={() => setSelectedProject(project)}
                  >
                    <ExternalLink className="w-5 h-5" />
                  </motion.button>
                </div>
              </div>
              <p className="text-text-secondary mb-4">{project.description[0]}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.tech_stack.map((tech) => (
                  <span
                    key={tech}
                    className="px-2 py-1 bg-primary/10 rounded-md text-xs font-medium text-primary"
                  >
                    {tech}
                  </span>
                ))}
              </div>
              <p className="text-sm text-text-secondary">{project.duration}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <ProjectDrawer
        project={selectedProject}
        isOpen={selectedProject !== null}
        onClose={() => setSelectedProject(null)}
      />
    </section>
  );
};