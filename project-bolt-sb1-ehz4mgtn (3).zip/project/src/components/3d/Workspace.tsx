import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text, Float } from '@react-three/drei';
import { Vector3 } from 'three';
import type { WorkExperience } from '../../types/portfolio';

interface WorkspaceProps {
  experience: WorkExperience;
  index: number;
  isSelected: boolean;
  onClick: () => void;
}

export const Workspace = ({ experience, index, isSelected, onClick }: WorkspaceProps) => {
  const groupRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (!groupRef.current) return;
    // Subtle floating animation
    groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5 + index) * 0.05;
  });

  const techStack = experience.responsibilities
    .join(' ')
    .match(/\b(React|TypeScript|JavaScript|Node|AWS|SQL|MongoDB)\b/g) || [];

  return (
    <group
      ref={groupRef}
      position={[index * 6 - 6, 0, 0]}
      onClick={onClick}
    >
      {/* Desk */}
      <mesh position={[0, -1.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <boxGeometry args={[4, 2, 0.1]} />
        <meshStandardMaterial color="#334155" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* Monitor */}
      <group position={[0, 0, -0.5]}>
        {/* Screen */}
        <mesh>
          <boxGeometry args={[3, 2, 0.1]} />
          <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.2} />
        </mesh>
        
        {/* Screen Content */}
        <group position={[-1.3, 0.7, 0.06]}>
          <Text
            position={[0, 0, 0]}
            fontSize={0.15}
            color="#94a3b8"
            anchorX="left"
            font="/fonts/JetBrainsMono-Regular.woff"
          >
            // {experience.company}
          </Text>
          
          <Text
            position={[0, -0.3, 0]}
            fontSize={0.12}
            color="#2563eb"
            anchorX="left"
            font="/fonts/JetBrainsMono-Regular.woff"
          >
            {experience.position}
          </Text>

          <Text
            position={[0, -0.5, 0]}
            fontSize={0.1}
            color="#8b5cf6"
            anchorX="left"
            font="/fonts/JetBrainsMono-Regular.woff"
          >
            {experience.duration}
          </Text>
        </group>

        {/* Stand */}
        <mesh position={[0, -1.2, 0.3]}>
          <cylinderGeometry args={[0.1, 0.1, 0.4]} />
          <meshStandardMaterial color="#475569" />
        </mesh>
        <mesh position={[0, -1.4, 0.15]}>
          <boxGeometry args={[0.6, 0.1, 0.3]} />
          <meshStandardMaterial color="#475569" />
        </mesh>
      </group>

      {/* Terminal Window */}
      <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
        <group position={[2, 0.5, 0]} rotation={[0, -Math.PI / 6, 0]}>
          <mesh>
            <boxGeometry args={[1.5, 1, 0.05]} />
            <meshStandardMaterial color="#1e1e1e" metalness={0.5} roughness={0.3} />
          </mesh>
          <group position={[-0.65, 0.3, 0.03]} scale={0.8}>
            <Text
              fontSize={0.08}
              color="#64748b"
              anchorX="left"
              font="/fonts/JetBrainsMono-Regular.woff"
            >
              $ Tech Stack
            </Text>
            {techStack.map((tech, i) => (
              <Text
                key={tech}
                position={[0, -0.15 * (i + 1), 0]}
                fontSize={0.08}
                color="#2563eb"
                anchorX="left"
                font="/fonts/JetBrainsMono-Regular.woff"
              >
                {tech}
              </Text>
            ))}
          </group>
        </group>
      </Float>

      {/* Task Board */}
      <Float speed={1.5} rotationIntensity={0.1} floatIntensity={0.3}>
        <group position={[-2, 0.5, 0]} rotation={[0, Math.PI / 6, 0]}>
          <mesh>
            <boxGeometry args={[1.5, 1, 0.05]} />
            <meshStandardMaterial color="#1e1e1e" metalness={0.5} roughness={0.3} />
          </mesh>
          <group position={[-0.65, 0.3, 0.03]} scale={0.8}>
            <Text
              fontSize={0.08}
              color="#64748b"
              anchorX="left"
              font="/fonts/JetBrainsMono-Regular.woff"
            >
              Tasks:
            </Text>
            {experience.responsibilities.slice(0, 3).map((task, i) => (
              <Text
                key={i}
                position={[0, -0.15 * (i + 1), 0]}
                fontSize={0.06}
                color="#94a3b8"
                anchorX="left"
                maxWidth={1.2}
                font="/fonts/JetBrainsMono-Regular.woff"
              >
                • {task.slice(0, 30)}...
              </Text>
            ))}
          </group>
        </group>
      </Float>

      {/* Selection indicator */}
      {isSelected && (
        <mesh position={[0, -1.55, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[4.2, 2.2]} />
          <meshStandardMaterial color="#2563eb" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  );
};