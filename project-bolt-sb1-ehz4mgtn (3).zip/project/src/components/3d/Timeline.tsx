import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Text } from '@react-three/drei';
import { Vector3 } from 'three';
import type { WorkExperience } from '../../types/portfolio';

interface TimelineProps {
  experiences: WorkExperience[];
  selectedIndex: number;
  onStationClick: (index: number) => void;
}

export const Timeline = ({ experiences, selectedIndex, onStationClick }: TimelineProps) => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.1;
  });

  return (
    <group ref={groupRef}>
      {/* Main track */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.05, 0.05, experiences.length * 2, 32]} />
        <meshStandardMaterial color="#2563eb" />
      </mesh>

      {/* Stations */}
      {experiences.map((exp, index) => {
        const position = new Vector3(0, -(index * 2) + experiences.length, 0);
        const isSelected = index === selectedIndex;

        return (
          <group key={index} position={position}>
            {/* Station sphere */}
            <mesh
              onClick={() => onStationClick(index)}
              onPointerOver={(e) => {
                e.stopPropagation();
                document.body.style.cursor = 'pointer';
              }}
              onPointerOut={() => {
                document.body.style.cursor = 'auto';
              }}
            >
              <sphereGeometry args={[0.2, 32, 32]} />
              <meshStandardMaterial
                color={isSelected ? '#8b5cf6' : '#2563eb'}
                emissive={isSelected ? '#8b5cf6' : '#2563eb'}
                emissiveIntensity={isSelected ? 0.5 : 0.2}
              />
            </mesh>

            {/* Station label */}
            <Text
              position={[1, 0, 0]}
              fontSize={0.2}
              color={isSelected ? '#8b5cf6' : '#94a3b8'}
              anchorX="left"
              anchorY="middle"
            >
              {exp.company}
            </Text>
          </group>
        );
      })}
    </group>
  );
};